package lab4.varb;

public class Cupcake extends Sweets{
    public Cupcake() {
    }

    public Cupcake(String name, double weight, SugarLevel sugarLevel) {
        super(name, weight, sugarLevel);
    }
}
