package lab4.varb;

public class Lollipop extends Sweets {
    public Lollipop() {
    }

    public Lollipop(String name, double weight, SugarLevel sugarLevel) {
        super(name, weight, sugarLevel);
    }
}
