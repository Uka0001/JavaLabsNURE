package lab4.varb;

public class Candy extends Sweets{
    public Candy() {
    }

    public Candy(String name, double weight, SugarLevel sugarLevel) {
        super(name, weight, sugarLevel);
    }
}
