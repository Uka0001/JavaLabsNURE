package lab4.varb;

public enum SugarLevel {
    LOW("Low"),
    MEDIUM("Medium"),
    HIGH("High");

    SugarLevel(String level) {
    }
}
